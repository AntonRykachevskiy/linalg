import matplotlib.pyplot as plt
from skimage import data, io, filters
import cv2


from TILT import *

class Img():
    def __init__(self, filename):
        self.fname = filename
        self.img = cv2.imread(self.fname)
        self.point = ()

    def getCoord(self):
        fig = plt.figure()
        ax = fig.add_subplot(111)
        plt.imshow(self.img)
        cid = fig.canvas.mpl_connect('button_press_event', self.__onclick__)
        plt.show()
        return self.point

    def __onclick__(self, click):
        self.point = (click.xdata, click.ydata)
        return self.point

    def getImg(self):
        return self.img

if __name__ == '__main__':

    input = Img('building.jpg')

    img = input.getImg()
    top_left = np.around(input.getCoord()).astype(int)
    bottom_right = np.around(input.getCoord()).astype(int)

    #print top_left
    #print bottom_right

    init_points = np.zeros((2, 2))
    init_points[0, 0] = top_left[0]
    init_points[0, 1] = bottom_right[0]
    init_points[1, 0] = top_left[1]
    init_points[1, 1] = bottom_right[1]

    init_points = init_points.astype(int)


    #check = cv2.imread('building_.jpg')

    # init_points = np.asarray([[0, check.shape[1]], [0, check.shape[0]]])

    #init_points = np.asarray([[30, 100], [40, 80]])

    plt.imshow(img[init_points[1][0]: init_points[1][1], init_points[0][0]: init_points[0][1]])
    plt.show()

    Ds, Dotau, A, E = TILT(img, 'homography', init_points, blur=0, pyramid=0, branch=0)

    plt.imshow(A)
    plt.show()

    plt.imshow(E)
    plt.show()

    print np.sum(E)
