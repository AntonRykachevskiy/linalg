from cv2 import GaussianBlur
from tilt_kernel import *
from utils import *


def TILT(input_image, mode, init_points, **kwargs):
    args = parse_TILT_arguments(**kwargs)
    args['mode'] = mode
    args['input_image'] = input_image
    args['initial_points'] = np.floor(init_points)
    # In focus size now first is X, then second is Y
    args['focus_size'] = np.asarray([init_points[1, 1]-args['initial_points'][1, 0], args['initial_points'][0, 1]-args['initial_points'][0, 0]])
    args['center'] = np.floor(np.mean(init_points, axis=1))
    args['focus_center'] = np.floor(np.asarray([args['focus_size'][1],  args['focus_size'][0]])/2.)
    print 'Focus_center\n', args['focus_center']
    focus_center = args['focus_center']
    XData = np.asarray([1-focus_center[0], args['focus_size'][1]-focus_center[0]])
    YData = np.asarray([1-focus_center[1], args['focus_size'][0]-focus_center[1]])

    print 'First check data'
    print 'XData\n', XData, '\nYData\n', YData


    original_args = args

    #creating boundaries of the image
    expand_rate = 0.8 #WTF is this shit
    initial_points = args['initial_points']
    left_bound = np.ceil(max(initial_points[0,0] - expand_rate * (initial_points[0,1] - initial_points[0,0]), 0))
    right_bound = np.floor(min(initial_points[0,1] + expand_rate * (initial_points[0,1] - initial_points[0,0]), input_image.shape[1]));
    top_bound = np.ceil(max(initial_points[1,0] - expand_rate * (initial_points[1,1] - initial_points[1,0]), 0))
    bottom_bound = np.floor(min(initial_points[1,1] + expand_rate*(initial_points[1,1] - initial_points[1,0]), input_image.shape[0]));
    new_image = np.zeros((bottom_bound - top_bound , right_bound - left_bound , input_image.shape[2]))

    print 'bounds'
    print left_bound
    print right_bound
    print  top_bound
    print bottom_bound

    for c in range(input_image.shape[2]):
        new_image[:,:,c]=input_image[top_bound:bottom_bound, left_bound:right_bound, c] #maybe miss one pixel? but whatever

    args['input_image'] = new_image

    args['center'] = args['center'] + np.asarray([1-left_bound, 1-top_bound])

    pre_scale_matrix=np.eye(3)

    min_length = original_args['focus_size']

    initial_tfm_matrix = args['initial_tfm_matrix']
    initial_tfm_matrix = np.linalg.inv(pre_scale_matrix).dot(initial_tfm_matrix).dot(pre_scale_matrix)
    args['initial_tfm_matrix'] = initial_tfm_matrix
    args['focus_size'] = np.around(args['focus_size']/pre_scale_matrix[0,0])
    args['center'] = args['center']/pre_scale_matrix[0,0]
    parent_path='./'

    if args['branch'] == 1:
        print 'Sorry, no branch yet'

    if args['pyramid'] == 1:
        downsample_matrix = np.array([[0.5, 0, 0], [0, 0.5, 0], [0, 0, 1]])
        upsample_matrix = np.linalg.inv(downsample_matrix)
        total_scale = np.ceil(np.max(np.log2(np.min(args['focus_size'])/args['focus_threshold']), 0));

        for scale in range(int(total_scale),-1,-1):
            # begin each level of the pyramid
            if total_scale - scale >= args['pyramid_max_level']:
                break

            # Blur if required
            #BULA HERNIA
            if args['blur'] == 1 and scale == 0:
                input_image = GaussianBlur(args['input_image'], (5,5), 4) ##GIVE KERNEL
                #input_image=imfilter(args.input_image, fspecial('gaussian', ceil(args.blur_kernel_size_k*2^scale), ceil(args.blur_kernel_sigma_k*2^scale)));
            else:
                input_image = args['input_image']


            # prepare image and initial tfm_matrix
            scale_matrix = np.linalg.matrix_power(downsample_matrix, scale)
            #tfm = maketform('projective', scale_matrix');
            #input_image=imtransform(input_image, tfm, 'bicubic');

            input_image = polina_transform(input_image, scale_matrix, inv_flag = False)

            print scale_matrix
            tfm_matrix = scale_matrix.dot(initial_tfm_matrix).dot(np.linalg.inv(scale_matrix))

            center = np.floor(transform_point(args['center'], scale_matrix));

            focus_size=np.floor(args['focus_size']/(2 ** scale))

            #args['save_path'] = fullfile(parent_path, ['pyramid', num2str(scale)]);
            #args.figure_no=100+total_scale-scale+1;
            Dotau, A, E, tfm_matrix, UData, VData, XData, YData, A_scale, Dotau_series = tilt_kernel(input_image, args['mode'], center, focus_size, tfm_matrix, args)
            # update tfm_matrix of the highest-resolution level.
            initial_tfm_matrix = np.linalg.inv(scale_matrix).dot(tfm_matrix).dot(scale_matrix)
            args['outer_tol']=args['outer_tol']*args['outer_tol_step']

        tfm_matrix=initial_tfm_matrix

    else:
        if args['blur'] == 1:
            img_size=np.shape(args['input_image'])
            img_size=img_size[:2]
            img_size=img_size[:2] # POLINA question: what is the point of this?
            gauss_kernel = np.ceil(args['blur_kernel_size_k']*max(img_size)/50).astype(int)
            if np.mod(gauss_kernel, 2) == 0:
                gauss_kernel += 1
            #if gauss_kernel == 1:
            #    gauss_kernel += 2   # Because GaussBlur with kernel size = 1 does not make sense
            # POLINA: I commented above because maybe we should forgo gauss for small images

            gauss_sigma = np.ceil(args['blur_kernel_sigma_k']*max(img_size)/50).astype(int)

            # POLINA: hopefully a more appropriate gaussian blur
            input_image = GaussianBlur(args['input_image'], (gauss_kernel, gauss_kernel), gauss_sigma)
        else:
            input_image = args['input_image']

        args['figure_no'] = 101
        args['save_path'] = os.path.join(parent_path, 'some_name')
        # POLINA: below seems to be a mistake
        print 'LALALALALALA\n', args['focus_size']
        #Dotau, A, E, tfm_matrix, UData, VData, XData, YData, A_scale, Dotau_series = tilt_kernel(args['input_image'], args['mode'], args['center'], args['focus_size'], args['initial_tfm_matrix'], args)
        Dotau, A, E, tfm_matrix, UData, VData, XData, YData, A_scale, Dotau_series = tilt_kernel(input_image,
                                                                                                 args['mode'],
                                                                                                 args['center'],
                                                                                                 args['focus_size'], args['initial_tfm_matrix'], args)
    args = original_args
    tfm_matrix = np.dot(pre_scale_matrix,np.dot(tfm_matrix,np.linalg.inv(pre_scale_matrix)))

    focus_size = args['focus_size']
    image_size = np.shape(args['input_image'])
    image_size = image_size[:2]
    image_center = args['center']
    focus_center = np.zeros((2, 1))
    focus_center[0] = np.floor((1+args['focus_size'][1])/2)
    focus_center[1] = np.floor((1+args['focus_size'][0])/2)

    UData = np.array([1-image_center[0], image_size[1]-image_center[0]])
    VData = np.array([1-image_center[1], image_size[0]-image_center[1]])
    XData = np.array([1-focus_center[0], args['focus_size'][1]-focus_center[0]])
    YData = np.array([1-focus_center[1], args['focus_size'][0]-focus_center[1]])

    print 'focus_size', focus_size, 'focus_center', focus_center

    top_left = np.array([XData[0], YData[0]])
    top_right = np.array([XData[1], YData[0]])
    bottom_left = np.array([XData[0], YData[1]])
    bottom_right = np.array([XData[1], YData[1]])

    print 'XData\n', XData, '\nYData\n', YData

    print 'top_left\n', top_left, '\ntop_right\n', top_right, '\nbottom_left\n', bottom_left, '\nbottom_right\n', bottom_right

    tf_top_left = np.round(transform_point(top_left, tfm_matrix) + image_center).astype(int)
    tf_top_right = np.round(transform_point(top_right, tfm_matrix) + image_center).astype(int)
    tf_bottom_left = np.round(transform_point(bottom_left, tfm_matrix) + image_center).astype(int)
    tf_bottom_right = np.round(transform_point(bottom_right, tfm_matrix) + image_center).astype(int)

    ac_top_left = np.round(np.array([XData[0], YData[0]]) + image_center).astype(int)
    ac_top_right = np.round(np.array([XData[1], YData[0]]) + image_center).astype(int)
    ac_bottom_left = np.round(np.array([XData[0], YData[1]]) + image_center).astype(int)
    ac_bottom_right = np.round(np.array([XData[1], YData[1]]) + image_center).astype(int)

    print 'tf_top_left\n', tf_top_left, '\ntf_top_right\n', tf_top_right, '\ntf_bottom_left\n', tf_bottom_left, '\ntf_bottom_right\n', tf_bottom_right
    #tf_focus_size = np.zeros(focus_size)
    #tf_focus_size = transform_point(input_pt, tfm_matrix)

    #fig, ax = plt.subplots(3, 1)
    #args['input_image'] = 255 - args['input_image']

    #out_image = cv2.line(args['input_image'], (ac_top_left[0], ac_top_left[1]), (ac_top_right[0], ac_top_right[1]),
    #                     (100, 250, 100))
    #out_image = cv2.line(args['input_image'], (init_points[0, 0], init_points[1, 0]), (init_points[0, 0], init_points[1, 1]),
     #                    (100, 250, 100))
    #out_image = cv2.line(args['input_image'], (init_points[0, 1], init_points[1, 1]), (init_points[0, 1], init_points[1, 0]),
     #                    (100, 250, 100))
    #out_image = cv2.line(args['input_image'], (init_points[0, 1], init_points[1, 1]), (init_points[0, 0], init_points[1, 1]),
      #                   (100, 250, 100))

    #out_image = cv2.line(args['input_image'], (tf_top_left[0], tf_top_left[1]), (tf_top_right[0], tf_top_right[1]),
      #                   (100,100,250))
    #out_image = cv2.line(args['input_image'], (tf_top_left[0], tf_top_left[1]), (tf_bottom_left[0], tf_bottom_left[1]),
      #                   (100, 100, 250))
    #out_image = cv2.line(args['input_image'], (tf_top_right[0], tf_top_right[1]), (tf_bottom_right[0], tf_bottom_right[1]),
      #                   (100, 100, 250))
    #out_image = cv2.line(args['input_image'], (tf_bottom_left[0], tf_bottom_left[1]), (tf_bottom_right[0], tf_bottom_right[1]),
      #                   (100, 100, 250))
    #ax[0].imshow(args['input_image'])
    #print np.amax(args['input_image'])

    #tf_x = [tf_top_left[0], tf_top_right[0], tf_bottom_left[0], tf_bottom_right[0]]
    #tf_y = [tf_top_left[1], tf_top_right[1], tf_bottom_left[1], tf_bottom_right[1]]

    #print 'tfx\n', tf_x
    #print 'tfy\n', tf_y

    # POLINA: from square input it was unclear, which is x and which is y
    #in_x = [init_points[0, 0], init_points[0, 0], init_points[0, 1], init_points[0, 1]]
    #in_y = [init_points[1, 0], init_points[1, 1], init_points[1, 0], init_points[1, 1]]

    # POLINA: might have confused x and y
    #ax[0].scatter(tf_x, tf_y, c='g')
    #ax[0].scatter(in_y, in_x, c='r')

    #ax[1].imshow(Dotau_series[0], cmap='gray')
    #ax[2].imshow(Dotau_series[-1], cmap='gray')


    #plt.show()

    return Dotau_series, Dotau, A, E
